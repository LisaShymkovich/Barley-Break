#include "digitalclock.h"

DigitalClock::DigitalClock()
{

}
