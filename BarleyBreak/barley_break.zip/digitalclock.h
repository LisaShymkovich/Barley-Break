#ifndef DIGITALCLOCK_H
#define DIGITALCLOCK_H
#include <QLCDNumber>


class DigitalClock: public QLCDNumber
{
public:
    DigitalClock();
};

#endif // DIGITALCLOCK_H
